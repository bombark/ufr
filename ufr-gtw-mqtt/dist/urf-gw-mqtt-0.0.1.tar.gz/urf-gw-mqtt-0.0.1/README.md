# MQTT Gateway for URF

# Dependencies

sudo apt install libmosquitto-dev